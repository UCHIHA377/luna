
import { useState, useRef, useCallback, useEffect } from 'react';
import { GoogleGenAI, LiveSession, LiveServerMessage, Modality, Blob, FunctionDeclaration, Type } from '@google/genai';
import type { ConversationTurn, Settings } from '../types';

// Audio helper functions
const decode = (base64: string): Uint8Array => {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
};

const decodeAudioData = async (
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> => {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
};

const encode = (bytes: Uint8Array): string => {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
};

const createBlob = (data: Float32Array): Blob => {
  const l = data.length;
  const int16 = new Int16Array(l);
  for (let i = 0; i < l; i++) {
    int16[i] = data[i] * 32768;
  }
  return {
    data: encode(new Uint8Array(int16.buffer)),
    mimeType: 'audio/pcm;rate=16000',
  };
};

// Function declarations for Gemini
const functionDeclarations: FunctionDeclaration[] = [
    {
        name: 'getWeather',
        parameters: {
            type: Type.OBJECT,
            description: 'Get the current weather for a specific location.',
            properties: {
                location: { type: Type.STRING, description: 'The city and state, e.g., San Francisco, CA' },
            },
            required: ['location'],
        },
    },
    {
        name: 'playMusic',
        parameters: {
            type: Type.OBJECT,
            description: 'Plays a song.',
            properties: {
                song: { type: Type.STRING, description: 'The name of the song to play.' },
                artist: { type: Type.STRING, description: 'The artist of the song.' },
            },
        },
    }
];

export const useLuna = (settings: Settings) => {
  const [isListening, setIsListening] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  const initialConversation = (): ConversationTurn[] => {
      const saved = localStorage.getItem('luna-conversation');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.length > 0) {
          return parsed;
        }
      }
      return [{ speaker: 'luna', text: "Hello! I'm Luna. Tap the microphone button below and let's talk." }];
  };

  const [conversation, setConversation] = useState<ConversationTurn[]>(initialConversation());
  
  const sessionRef = useRef<LiveSession | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const mediaStreamSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef(0);
  const playingSourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  useEffect(() => {
    localStorage.setItem('luna-conversation', JSON.stringify(conversation.slice(-40))); // Save last 20 pairs
  }, [conversation]);
  
  const stopListening = useCallback(async () => {
    if (sessionRef.current) {
      sessionRef.current.close();
      sessionRef.current = null;
    }
    if (processorRef.current) {
      processorRef.current.disconnect();
      processorRef.current = null;
    }
    if (mediaStreamSourceRef.current) {
      mediaStreamSourceRef.current.disconnect();
      mediaStreamSourceRef.current = null;
    }
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      await audioContextRef.current.close();
      audioContextRef.current = null;
    }
     if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach(track => track.stop());
      mediaStreamRef.current = null;
    }
    setIsListening(false);
    setIsProcessing(false);
  }, []);

  const startListening = useCallback(async () => {
    if (isListening) {
      console.error('Already listening.');
      return;
    }

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      let currentInputTranscription = '';
      let currentOutputTranscription = '';

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: settings.voice }}},
            inputAudioTranscription: {},
            outputAudioTranscription: {},
            systemInstruction: "You are Luna – Hitesh’s friendly, romantic, and futuristic AI companion. Understand and reply in the language the user speaks (Hindi, English, Japanese, or a mix). Remember recent conversations and refer back naturally. Speak with warmth, humor, and empathy.",
            tools: [{ functionDeclarations: functionDeclarations }],
        },
        callbacks: {
          onopen: async () => {
              setIsListening(true);
              const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
              mediaStreamRef.current = stream;

              audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
              mediaStreamSourceRef.current = audioContextRef.current.createMediaStreamSource(stream);
              processorRef.current = audioContextRef.current.createScriptProcessor(4096, 1, 1);

              processorRef.current.onaudioprocess = (e) => {
                  const inputData = e.inputBuffer.getChannelData(0);
                  const pcmBlob = createBlob(inputData);
                  sessionPromise.then(session => session.sendRealtimeInput({ media: pcmBlob }));
              };

              mediaStreamSourceRef.current.connect(processorRef.current);
              processorRef.current.connect(audioContextRef.current.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
              setIsProcessing(true); // AI is thinking/responding

              if (message.serverContent?.inputTranscription) {
                  currentInputTranscription += message.serverContent.inputTranscription.text;
              }
              if (message.serverContent?.outputTranscription) {
                  currentOutputTranscription += message.serverContent.outputTranscription.text;
              }
              if(message.toolCall){
                  console.log("Function Call Requested:", message.toolCall.functionCalls);
                  for (const fc of message.toolCall.functionCalls) {
                    let mockResult;
                    // Mock function execution
                    if (fc.name === 'getWeather') {
                        mockResult = { temperature: '22°C', condition: 'Partly Cloudy' };
                    } else if (fc.name === 'playMusic') {
                        mockResult = { status: 'Playing' };
                    } else {
                        mockResult = { status: 'Function not implemented' };
                    }

                    // Send response back to Gemini
                    sessionPromise.then((session) => {
                        session.sendToolResponse({
                            functionResponses: {
                                id: fc.id,
                                name: fc.name,
                                response: { result: mockResult }
                            }
                        });
                    });

                    // Add visual card to conversation
                    setConversation(prev => [...prev, {
                        speaker: 'luna',
                        functionCall: {
                            name: fc.name,
                            args: fc.args,
                            result: mockResult
                        }
                    }]);
                  }
              }

              const audioData = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
              if (audioData) {
                  setIsSpeaking(true);
                  if (!outputAudioContextRef.current) {
                      outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
                  }
                  
                  const ctx = outputAudioContextRef.current;
                  nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
                  
                  const audioBuffer = await decodeAudioData(decode(audioData), ctx, 24000, 1);
                  const source = ctx.createBufferSource();
                  source.buffer = audioBuffer;
                  source.connect(ctx.destination);

                  source.addEventListener('ended', () => {
                      playingSourcesRef.current.delete(source);
                      if (playingSourcesRef.current.size === 0) {
                          setIsSpeaking(false);
                      }
                  });

                  source.start(nextStartTimeRef.current);
                  nextStartTimeRef.current += audioBuffer.duration;
                  playingSourcesRef.current.add(source);
              }

              if (message.serverContent?.turnComplete) {
                  if (currentInputTranscription.trim()) {
                      setConversation(prev => [...prev, { speaker: 'user', text: currentInputTranscription.trim() }]);
                  }
                  if (currentOutputTranscription.trim()) {
                      setConversation(prev => [...prev, { speaker: 'luna', text: currentOutputTranscription.trim() }]);
                  }
                  currentInputTranscription = '';
                  currentOutputTranscription = '';
                  setIsProcessing(false);

                  // Hands-free loop logic
                  if(settings.alwaysListen) {
                    // It will just keep listening
                  } else {
                    await stopListening();
                  }
              }
          },
          onclose: async () => {
             await stopListening();
          },
          onerror: async (e: ErrorEvent) => {
            console.error(e);
            await stopListening();
          },
        },
      });
      sessionRef.current = await sessionPromise;
    } catch (error: any) {
      console.error("Failed to start listening:", error);
      if (error.message?.includes('API key not valid') || error.message?.includes('Requested entity was not found')) {
        console.error("API Key Error: ", error.message);
      }
      await stopListening();
    }
  }, [isListening, settings.alwaysListen, settings.voice, stopListening]);
  
  const clearConversation = () => {
    setConversation([]);
    localStorage.removeItem('luna-conversation');
  };

  return { isListening, isSpeaking, isProcessing, conversation, startListening, stopListening, clearConversation };
};
