
import React from 'react';
import type { ConversationTurn } from '../types';
import { MusicIcon, WeatherIcon } from './Icons';

// --- Helper components for function call cards ---

interface CardProps {
  children: React.ReactNode;
}

const Card: React.FC<CardProps> = ({ children }) => (
  <div className="bg-purple-700/80 backdrop-blur-sm rounded-lg p-4 max-w-xs md:max-w-md shadow-md border border-purple-500/30">
    {children}
  </div>
);

const WeatherCard: React.FC<{ args: any; result: any }> = ({ args, result }) => (
  <Card>
    <div className="flex items-center space-x-4">
      <WeatherIcon condition={result.condition} />
      <div>
        <p className="text-sm text-gray-300">{args.location}</p>
        <p className="text-3xl font-bold text-white">{result.temperature}</p>
        <p className="text-indigo-200">{result.condition}</p>
      </div>
    </div>
  </Card>
);

const MusicCard: React.FC<{ args: any }> = ({ args }) => (
  <Card>
    <div className="flex items-center space-x-4">
      <div className="w-16 h-16 bg-indigo-500/50 rounded-md flex items-center justify-center">
        <MusicIcon />
      </div>
      <div>
        <p className="text-sm text-gray-300">Now Playing...</p>
        <p className="text-lg font-bold text-white truncate">{args.song}</p>
        <p className="text-indigo-200">{args.artist || 'Unknown Artist'}</p>
      </div>
    </div>
  </Card>
);

// --- Main ChatBubble component ---

interface ChatBubbleProps {
  turn: ConversationTurn;
}

export const ChatBubble: React.FC<ChatBubbleProps> = ({ turn }) => {
  const isUser = turn.speaker === 'user';
  const bubbleClass = isUser
    ? 'bg-indigo-500 rounded-br-none self-end'
    : 'bg-purple-700 rounded-bl-none self-start';
  const containerClass = isUser ? 'justify-end' : 'justify-start';

  if (turn.functionCall) {
    const { name, args, result } = turn.functionCall;
    return (
      <div className={`flex justify-start mb-4 animate-fade-in`}>
        {name === 'getWeather' && result && <WeatherCard args={args} result={result} />}
        {name === 'playMusic' && <MusicCard args={args} />}
      </div>
    );
  }

  if (!turn.text) {
    return null;
  }

  return (
    <div className={`flex ${containerClass} mb-4 animate-fade-in`}>
      <div className={`max-w-xs md:max-w-md lg:max-w-2xl px-4 py-3 rounded-2xl shadow-md ${bubbleClass}`}>
        <p className={`text-base leading-relaxed text-white`}>{turn.text}</p>
      </div>
    </div>
  );
};
