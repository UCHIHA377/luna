import React, { useState, useRef, useEffect } from 'react';
import { useLuna } from './hooks/useLuna';
import type { ConversationTurn, Settings } from './types';
import { MicButton } from './components/MicButton';
import { ChatBubble } from './components/ChatBubble';
import { SettingsModal } from './components/SettingsModal';
import { MemoryModal } from './components/MemoryModal';
import { Waveform } from './components/Waveform';
import { InstallPrompt } from './components/InstallPrompt';
import { SettingsIcon, MemoryIcon, GithubIcon, ShareIcon, CloseIcon } from './components/Icons';

// --- Share Modal Component ---
const ShareModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  // This is a placeholder QR code SVG. It is for visual demonstration purposes
  // and does not encode a real, scannable URL.
  const QrCodeSvg = () => (
    <svg viewBox="0 0 33 33" className="w-48 h-48 bg-white p-2 rounded-lg shadow-inner" aria-label="Example QR Code">
        <path d="M0 0h8v8H0z m13 0h8v8h-8z m12 0h8v8h-8z M8 0V8h5V0z m-3 9v5H0v-5z m-1 1h3v3H1z m1 1v1h1v-1z m16-5h-5v8h5z m-1 1v6h-3v-6z m-1 1h-1v4h1z m-1 1v2h-1v-2z m-1 1h-1v1h1z m14 3h-5v5h5z m-1 1v3h-3v-3z m-1 1h-1v1h1z M0 13h8v8H0z m13 0h8v8h-8z m12 0h8v8h-8z m-1-1v-3h-3v3z m-1-1h1v1h-1z m-15-1h5v5h-5z m1-1v-1H9v1z m4 0h-1v1h1z m-3 2h1v-1h1v1h1v1h-1v1h-1v-1h-1z m14-1h-3v3h3z m-1 1h-1v1h1z m-9-6h1v1h-1z m-1 1h-1v1h1z m-1 1h1v1h-1z m-1 1h-1v1h1z m1-4h1v1h-1z m-1 1h-1v1h1z m1-2h1v1h-1z m-1 1h-1v1h1z m-1 1h1v1h-1z m-1 1h-1v1h1z m1-4h1v1h-1z m-1 1h-1v1h1z m1 1h1v1h-1z m-1 1h-1v1h1z m1 1h1v1h-1z m-1 1h-1v1h1z m1 1h1v1h-1z m-1 1h-1v1h1z m2 1v1h-1v-1z m0-2v1h-1v-1z m-1 1h-1v1h1z m-1 1v1h-1v-1z m-1-1h-1v1h1z m-1 1v1h-1v-1z m-1-1h-1v1h1z m0-2h-1v1h1z m0 1h-1v1h1z m2 1v1h-1v-1z m-1-1h-1v1h1z m-1 1v1h-1v-1z m-1-1h-1v1h1z m-1 1v1h-1v-1z m-1-1h-1v1h1z m-1 1v1h-1v-1z m-1-1h-1v1h1z m-1 1v1h-1v-1z m1-5h1v1h-1z m-1-1h-1v1h1z m1 1h1v1h-1z m-1 1h-1v1h1z m1 1h1v1h-1z m-1 1h-1v1h1z m1 1h1v1h-1z m-1 1h-1v1h1z m-1 1h1v1h-1z m-1 1h-1v1h1z m1 1h1v1h-1z m-1 1h-1v1h1z m1 1h1v1h-1z m-1 1h-1v1h1z m1 1h1v1h-1z m-1 1h-1v1h1z m2-13v1h-1v-1z m-1-1v1h-1v-1z m-1 1h-1v1h1z m-1 1v1h-1v-1z m-1-1h-1v1h1z m-1 1v1h-1v-1z m-1-1h-1v1h1z m-1 1v1h-1v-1z m1 1h1v1h-1z m17-5h1v1h-1z m1-1h1v1h-1z m-3 0h1v1h-1z m-1 1h1v1h-1z m-1-1h1v1h-1z m1 3h1v1h-1z m-1-1h1v1h-1z m-1-1h1v1h-1z m3 0h1v1h-1z m1-1h1v1h-1z m-1 2h1v1h-1z m1 1h1v1h-1z m-1-3h1v1h-1z m-1 1h1v1h-1z m1-1h1v1h-1z m1 4h1v1h-1z m-1 1h1v1h-1z m1-1h1v1h-1z m-4-1h1v1h-1z m-1 1h1v1h-1z m1-1h1v1h-1z m-1-1h1v1h-1z m1 3h1v1h-1z m1 1h1v1h-1z m1-1h1v1h-1z"/>
    </svg>
  );
  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 animate-fade-in">
      <div className="bg-gradient-to-br from-indigo-800 to-purple-800 rounded-lg shadow-2xl p-6 w-full max-w-md m-4 text-white border border-purple-500/50">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold">Install on Your Phone</h2>
          <button onClick={onClose} className="hover:text-indigo-300 transition-colors" aria-label="Close">
            <CloseIcon />
          </button>
        </div>

        <div className="text-center mb-6">
          <p className="text-indigo-200 mb-4">
            Scan this QR code with your phone's camera to open Luna.
          </p>
          <div className="flex justify-center">
            <QrCodeSvg />
          </div>
          <p className="text-xs text-gray-400 mt-2">
            (This is an example. If this were a published app, you'd scan its public URL here.)
          </p>
        </div>

        <div>
          <h3 className="text-lg font-semibold mb-2">Then, Add to Home Screen:</h3>
          <div className="bg-black/20 p-4 rounded-lg space-y-3">
            <div>
              <p className="font-bold">On iPhone (Safari):</p>
              <p className="text-sm text-indigo-200">Tap the 'Share' icon <span className="inline-block mx-1">􀈂</span>, then scroll down and tap 'Add to Home Screen'.</p>
            </div>
            <hr className="border-purple-600/50"/>
            <div>
              <p className="font-bold">On Android (Chrome):</p>
              <p className="text-sm text-indigo-200">Tap the 'three dots' menu <span className="inline-block mx-1">􀫶</span>, then tap 'Install app' or 'Add to Home screen'.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};


const App: React.FC = () => {
  const [showSettings, setShowSettings] = useState(false);
  const [showMemory, setShowMemory] = useState(false);
  const [showShare, setShowShare] = useState(false);
  const [installPromptEvent, setInstallPromptEvent] = useState<Event | null>(null);
  
  const initialSettings = (): Settings => {
    const saved = localStorage.getItem('luna-settings');
    if (saved) {
      return JSON.parse(saved);
    }
    return { alwaysListen: false, voice: 'Zephyr' };
  };
  const [settings, setSettings] = useState<Settings>(initialSettings);
  
  const {
    isListening,
    isSpeaking,
    isProcessing,
    conversation,
    startListening,
    stopListening,
    clearConversation,
  } = useLuna(settings);

  const chatContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleBeforeInstallPrompt = (event: Event) => {
      event.preventDefault();
      setInstallPromptEvent(event);
    };
    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  useEffect(() => {
    localStorage.setItem('luna-settings', JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [conversation]);

  const handleClearMemory = () => {
    clearConversation();
    setShowMemory(false);
  };

  const handleInstall = () => {
    if (!installPromptEvent) return;
    (installPromptEvent as any).prompt();
    (installPromptEvent as any).userChoice.then((choiceResult: { outcome: string }) => {
      if (choiceResult.outcome === 'accepted') {
        console.log('User accepted the install prompt');
      } else {
        console.log('User dismissed the install prompt');
      }
      setInstallPromptEvent(null);
    });
  };

  return (
    <div className="h-screen w-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-blue-900 text-white flex flex-col font-sans overflow-hidden">
      <header className="flex justify-between items-center p-4 backdrop-blur-sm bg-black/20 z-10">
        <h1 className="text-2xl font-bold tracking-wider">Luna</h1>
        <div className="flex items-center space-x-4">
           <button onClick={() => setShowShare(true)} className="text-white hover:text-indigo-300 transition-colors" aria-label="Share App">
            <ShareIcon />
          </button>
          <button onClick={() => setShowMemory(true)} className="text-white hover:text-indigo-300 transition-colors" aria-label="View Memory">
            <MemoryIcon />
          </button>
          <button onClick={() => setShowSettings(true)} className="text-white hover:text-indigo-300 transition-colors" aria-label="Open Settings">
            <SettingsIcon />
          </button>
          <a href="https://github.com/google/genai-js" target="_blank" rel="noopener noreferrer" className="text-white hover:text-indigo-300 transition-colors" aria-label="View on GitHub">
            <GithubIcon />
          </a>
        </div>
      </header>

      {installPromptEvent && (
        <InstallPrompt onInstall={handleInstall} onDismiss={() => setInstallPromptEvent(null)} />
      )}

      <main ref={chatContainerRef} className="flex-1 flex flex-col p-4 overflow-y-auto">
        <div className="flex-grow" />
        {conversation.map((turn: ConversationTurn, index: number) => (
          <ChatBubble key={index} turn={turn} />
        ))}
      </main>

      <footer className="flex flex-col items-center justify-center p-6 space-y-4 backdrop-blur-sm bg-black/20">
        <div className="h-16 w-full flex items-center justify-center">
            {(isListening || isSpeaking) && <Waveform isSpeaking={isSpeaking} />}
        </div>
        <MicButton 
          isListening={isListening} 
          isProcessing={isProcessing} 
          onClick={isListening ? stopListening : startListening} 
          disabled={isProcessing}
        />
      </footer>

      {showSettings && (
        <SettingsModal
          settings={settings}
          onSettingsChange={setSettings}
          onClose={() => setShowSettings(false)}
        />
      )}

      {showMemory && (
        <MemoryModal
          conversation={conversation}
          onClear={handleClearMemory}
          onClose={() => setShowMemory(false)}
        />
      )}
      
      {showShare && <ShareModal onClose={() => setShowShare(false)} />}
    </div>
  );
};

export default App;
