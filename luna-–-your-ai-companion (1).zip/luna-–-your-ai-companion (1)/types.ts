
export interface FunctionCallInfo {
  name: string;
  args: any;
  result?: any;
}

export interface ConversationTurn {
  speaker: 'user' | 'luna';
  text?: string;
  functionCall?: FunctionCallInfo;
}

export interface Settings {
  alwaysListen: boolean;
  voice: string;
}
