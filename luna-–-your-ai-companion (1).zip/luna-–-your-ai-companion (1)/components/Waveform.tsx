
import React from 'react';

interface WaveformProps {
  isSpeaking: boolean;
}

export const Waveform: React.FC<WaveformProps> = ({ isSpeaking }) => {
  const barColor = isSpeaking ? 'bg-purple-400' : 'bg-indigo-400';

  return (
    <div className="flex justify-center items-center space-x-1.5 h-full">
      <div className={`w-1.5 h-4 ${barColor} rounded-full animate-wave delay-75`}></div>
      <div className={`w-1.5 h-8 ${barColor} rounded-full animate-wave`}></div>
      <div className={`w-1.5 h-10 ${barColor} rounded-full animate-wave delay-150`}></div>
      <div className={`w-1.5 h-6 ${barColor} rounded-full animate-wave delay-300`}></div>
      <div className={`w-1.5 h-10 ${barColor} rounded-full animate-wave delay-200`}></div>
      <div className={`w-1.5 h-8 ${barColor} rounded-full animate-wave delay-75`}></div>
      <div className={`w-1.5 h-4 ${barColor} rounded-full animate-wave delay-150`}></div>
    </div>
  );
};

// Add keyframes to index.html or a global style setup.
// For this project, we'll embed it in a style tag for simplicity.
const style = document.createElement('style');
style.innerHTML = `
  @keyframes wave {
    0%, 100% { transform: scaleY(0.5); }
    50% { transform: scaleY(1.5); }
  }
  .animate-wave {
    animation: wave 1.2s ease-in-out infinite;
  }
  @keyframes fade-in {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }
  .animate-fade-in {
    animation: fade-in 0.3s ease-out forwards;
  }
`;
document.head.appendChild(style);
