
import React from 'react';
import type { Settings } from '../types';
import { CloseIcon } from './Icons';

interface SettingsModalProps {
  settings: Settings;
  onSettingsChange: (newSettings: Settings) => void;
  onClose: () => void;
}

const VOICES = ['Zephyr', 'Kore', 'Puck', 'Charon', 'Fenrir'];

export const SettingsModal: React.FC<SettingsModalProps> = ({ settings, onSettingsChange, onClose }) => {
  const handleToggle = () => {
    onSettingsChange({ ...settings, alwaysListen: !settings.alwaysListen });
  };

  const handleVoiceChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    onSettingsChange({ ...settings, voice: e.target.value });
  };

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 animate-fade-in">
      <div className="bg-gradient-to-br from-indigo-800 to-purple-800 rounded-lg shadow-2xl p-6 w-full max-w-md m-4 text-white border border-purple-500/50">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Settings</h2>
          <button onClick={onClose} className="hover:text-indigo-300 transition-colors">
            <CloseIcon />
          </button>
        </div>

        <div className="space-y-6">
          <div className="flex items-center justify-between bg-black/20 p-4 rounded-lg">
            <label htmlFor="always-listen" className="font-medium">Always-Listening Mode</label>
            <div
              onClick={handleToggle}
              className={`w-14 h-8 flex items-center rounded-full p-1 cursor-pointer transition-colors ${settings.alwaysListen ? 'bg-indigo-500' : 'bg-gray-600'}`}
            >
              <div
                className={`bg-white w-6 h-6 rounded-full shadow-md transform transition-transform ${settings.alwaysListen ? 'translate-x-6' : ''}`}
              />
            </div>
          </div>
          
          <div className="bg-black/20 p-4 rounded-lg">
             <label htmlFor="voice-select" className="block font-medium mb-2">Luna's Voice</label>
             <select
                id="voice-select"
                value={settings.voice}
                onChange={handleVoiceChange}
                className="w-full bg-gray-700 border border-gray-600 rounded-md p-2 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
             >
                {VOICES.map(voice => (
                    <option key={voice} value={voice}>{voice}</option>
                ))}
             </select>
          </div>
        </div>
      </div>
    </div>
  );
};
