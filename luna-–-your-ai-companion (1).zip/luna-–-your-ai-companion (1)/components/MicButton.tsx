
import React from 'react';
import { MicIcon, StopIcon } from './Icons';

interface MicButtonProps {
  isListening: boolean;
  isProcessing: boolean;
  onClick: () => void;
}

export const MicButton: React.FC<MicButtonProps> = ({ isListening, isProcessing, onClick }) => {
  const getButtonClass = () => {
    let baseClass = "rounded-full p-6 flex items-center justify-center transition-all duration-300 ease-in-out shadow-lg focus:outline-none focus:ring-4";
    if (isListening) {
      return `${baseClass} bg-red-500 hover:bg-red-600 focus:ring-red-400`;
    }
    if (isProcessing) {
      return `${baseClass} bg-yellow-500 cursor-not-allowed animate-pulse focus:ring-yellow-400`;
    }
    return `${baseClass} bg-indigo-500 hover:bg-indigo-600 focus:ring-indigo-400`;
  };

  return (
    <button
      onClick={onClick}
      disabled={isProcessing}
      className={getButtonClass()}
      aria-label={isListening ? "Stop listening" : "Start listening"}
    >
      {isListening ? (
        <StopIcon />
      ) : (
        <MicIcon animate={isProcessing} />
      )}
    </button>
  );
};
