
import React from 'react';
import type { ConversationTurn } from '../types';
import { ChatBubble } from './ChatBubble';
import { CloseIcon, TrashIcon } from './Icons';

interface MemoryModalProps {
  conversation: ConversationTurn[];
  onClear: () => void;
  onClose: () => void;
}

export const MemoryModal: React.FC<MemoryModalProps> = ({ conversation, onClear, onClose }) => {
  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 animate-fade-in">
      <div className="bg-gradient-to-br from-indigo-800 to-purple-800 rounded-lg shadow-2xl p-6 w-full max-w-lg m-4 text-white border border-purple-500/50 flex flex-col h-[80vh]">
        <div className="flex justify-between items-center mb-4 flex-shrink-0">
          <h2 className="text-2xl font-bold">Memory</h2>
          <div className="flex items-center space-x-4">
            <button onClick={onClear} className="flex items-center space-x-2 text-red-400 hover:text-red-300 transition-colors">
              <TrashIcon />
              <span>Forget All</span>
            </button>
            <button onClick={onClose} className="hover:text-indigo-300 transition-colors">
              <CloseIcon />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto pr-2">
          {conversation.length > 0 ? (
            conversation.map((turn, index) => <ChatBubble key={index} turn={turn} />)
          ) : (
            <div className="flex items-center justify-center h-full">
              <p className="text-gray-400">No memories yet. Start a conversation!</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
