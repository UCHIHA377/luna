import React from 'react';
import { CloseIcon } from './Icons';

interface InstallPromptProps {
  onInstall: () => void;
  onDismiss: () => void;
}

export const InstallPrompt: React.FC<InstallPromptProps> = ({ onInstall, onDismiss }) => {
  return (
    <div className="bg-indigo-600/80 backdrop-blur-sm p-3 flex items-center justify-between animate-fade-in z-20">
      <p className="text-white text-sm md:text-base font-medium">Get the full app experience!</p>
      <div className="flex items-center space-x-3">
        <button
          onClick={onInstall}
          className="bg-white text-indigo-700 font-bold py-2 px-4 rounded-lg hover:bg-indigo-100 transition-colors text-sm"
        >
          Install
        </button>
        <button onClick={onDismiss} className="text-white hover:text-indigo-200 transition-colors">
          <CloseIcon />
        </button>
      </div>
    </div>
  );
};
